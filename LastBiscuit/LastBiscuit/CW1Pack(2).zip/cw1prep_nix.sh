javac TriangleNum.java
java TriangleNum < $1.txt > output.txt
diff $1output.txt output.txt
